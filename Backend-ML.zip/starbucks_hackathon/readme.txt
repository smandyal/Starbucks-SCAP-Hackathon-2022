pip3 install -r requirements.txt

run the above command using python3


URLs for api :
http://127.0.0.1:5000/generate_booth_prediction/2022-03-05

http://127.0.0.1:5000/generate_lincenses_prediction/2022-03-05
