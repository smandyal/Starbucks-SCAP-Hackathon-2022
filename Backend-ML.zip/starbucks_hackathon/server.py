import pandas as pd
from datetime import datetime, timedelta
from flask import Flask, jsonify, request
from flask_cors import CORS, cross_origin
import pickle
import pandas as pd


app = Flask(__name__)
@app.route("/generate_lincenses_prediction/<date>")

def generate_lincenses_prediction(date):
    date = pd.to_datetime(date)
    dates = []
    for i in range(10):
        curr_time = date+timedelta(hours=i,minutes=0)
        dates.append(curr_time)
    df = pd.DataFrame({"ds":dates})
    with open("licenses_prediction.pckl", "rb") as model:
        license_model = pickle.load(model)
    forecast2 = license_model.predict(df)
    data = forecast2[["ds", "yhat"]]
    data.yhat = data.yhat.astype(int)
    ret = data.to_json(orient="records", date_format="iso")
    return ret
@app.route("/generate_booth_prediction/<date>")
def generate_booth_prediction(date):
    date = pd.to_datetime(date)
    dates = []
    for i in range(10):
        curr_time = date+timedelta(hours=i,minutes=0)
        dates.append(curr_time)
    df = pd.DataFrame({"ds":dates})
    with open("booths_prediction.pckl", "rb") as model:
        license_model = pickle.load(model)
    forecast2 = license_model.predict(df)
    data = forecast2[["ds", "yhat"]]
    data.yhat = data.yhat.astype(int)
    ret = data.to_json(orient="records", date_format="iso")
    return ret

if __name__ == "__main__":
   app.run()
